#!/usr/bin/env python3
import rospy
import psutil
import os
import numpy as np
from datetime import datetime
from geometry_msgs.msg import PoseStamped, TwistStamped
from nav_msgs.msg import Odometry
from mavros_msgs.msg import State
from sensor_msgs.msg import TimeReference
from std_msgs.msg import Float64, Bool, Header
import tf2_ros

class Colors:
    OK = '\033[92m'
    WARN = '\033[93m'
    ERR = '\033[91m'
    INFO = '\033[94m'
    END = '\033[0m'

class PreflightMonitor:
    def __init__(self):
        rospy.init_node("preflight_monitor")
        
        # Config
        self.odom_topic = rospy.get_param("~odom_topic", "/Odometry")
        self.pose_topic = rospy.get_param("~pose_topic", "/mavros/vision_pose/pose")
        self.state_topic = rospy.get_param("~state_topic", "/mavros/state")
        self.map_frame = rospy.get_param("~map_frame", "map")
        self.base_frame = rospy.get_param("~base_frame", "base_link")
        self.log_dir = rospy.get_param("~log_dir", os.path.expanduser("~/preflight_logs"))
        self.max_pose_delay = rospy.get_param("~max_pose_delay", 0.5)
        self.min_pose_rate = rospy.get_param("~min_pose_rate", 20.0)
        self.max_cpu = rospy.get_param("~max_cpu", 85.0)
        self.max_ram = rospy.get_param("~max_ram", 85.0)
        self.max_time_sync_ms = rospy.get_param("~max_time_sync_ms", 50.0)
        self.min_disk_gb = rospy.get_param("~min_disk_gb", 5.0)
        self.max_position_jump = rospy.get_param("~max_position_jump", 3.0)
        
        # State
        self.mavros_connected = False
        self.armed = False
        self.fcu_mode = "UNKNOWN"
        self.last_odom = None
        self.last_odom_time = rospy.Time(0)
        self.last_pose_time = rospy.Time(0)
        self.pose_window_count = 0
        self.last_rate_check = rospy.Time.now()
        self.time_sync_ms = None
        self.last_position = None
        self.critical_active = False
        
        # Logging
        os.makedirs(self.log_dir, exist_ok=True)
        self.log_path = os.path.join(self.log_dir, 
                                     f"preflight_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        
        # TF
        self.tf_buffer = tf2_ros.Buffer(rospy.Duration(30.0))
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)
        
        # Pub/Sub
        self.diag_pub = rospy.Publisher("/preflight/critical", Bool, queue_size=1)
        self.rate_pub = rospy.Publisher("/preflight/pose_rate", Float64, queue_size=1)
        
        rospy.Subscriber(self.state_topic, State, self.state_cb)
        rospy.Subscriber(self.odom_topic, Odometry, self.odom_cb)
        rospy.Subscriber(self.pose_topic, PoseStamped, self.pose_cb)
        rospy.Subscriber("/mavros/time_reference", TimeReference, self.time_cb)
        
        self.timer = rospy.Timer(rospy.Duration(1.0), self.check)
        rospy.loginfo(f"{Colors.INFO}[monitor] Started. Log: {self.log_path}{Colors.END}")
    
    def log(self, level, text):
        ts = rospy.Time.now().to_sec()
        line = f"{level:8s} | {ts:.3f} | {text}"
        with open(self.log_path, 'a') as f:
            f.write(line + "\n")
        
        if level == "CRITICAL":
            print(f"{Colors.ERR}{line}{Colors.END}")
        elif level == "WARN":
            print(f"{Colors.WARN}{line}{Colors.END}")
        elif level == "OK":
            print(f"{Colors.OK}{line}{Colors.END}")
        else:
            print(f"{Colors.INFO}{line}{Colors.END}")
    
    def state_cb(self, msg):
        self.mavros_connected = msg.connected
        self.armed = msg.armed
        self.fcu_mode = msg.mode
    
    def odom_cb(self, msg):
        now = rospy.Time.now()
        self.last_odom = msg
        self.last_odom_time = now
        
        # NaN check
        p = msg.pose.pose.position
        if any(np.isnan(v) for v in [p.x, p.y, p.z]):
            self.log("CRITICAL", "NaN in FAST-LIO position!")
        
        # Jump check
        if self.last_position is not None:
            dx = p.x - self.last_position[0]
            dy = p.y - self.last_position[1]
            dz = p.z - self.last_position[2]
            dist = np.sqrt(dx**2 + dy**2 + dz**2)
            dt = max((now - self.last_odom_time).to_sec(), 0.001)
            if dist > self.max_position_jump and dt < 1.0:
                self.log("CRITICAL", f"POSITION JUMP: {dist:.2f} m in {dt:.3f} s")
        self.last_position = (p.x, p.y, p.z)
    
    def pose_cb(self, msg):
        self.last_pose_time = rospy.Time.now()
        self.pose_window_count += 1
    
    def time_cb(self, msg):
        if msg.time_ref:
            off = (rospy.Time.now() - msg.time_ref).to_sec()
            self.time_sync_ms = abs(off) * 1000.0
    
    def check(self, event):
        now = rospy.Time.now()
        issues = []
        critical = False
        
        # MAVROS
        if not self.mavros_connected:
            issues.append(("CRITICAL", "MAVROS disconnected"))
            critical = True
        else:
            issues.append(("OK", f"MAVROS connected | Mode: {self.fcu_mode}"))
        
        # Armed safety
        if self.armed:
            issues.append(("WARN", "VEHICLE ARMED"))
        
        # Odometry freshness
        odom_delay = (now - self.last_odom_time).to_sec() if self.last_odom_time > rospy.Time(0) else 999
        if odom_delay > self.max_pose_delay:
            issues.append(("CRITICAL", f"FAST-LIO stale: {odom_delay:.2f} s"))
            critical = True
        else:
            issues.append(("OK", f"FAST-LIO delay: {odom_delay*1000:.0f} ms"))
        
        # Pose rate
        dt = (now - self.last_rate_check).to_sec()
        if dt >= 1.0:
            rate = self.pose_window_count / dt
            self.pose_window_count = 0
            self.last_rate_check = now
            self.rate_pub.publish(Float64(rate))
            if rate < self.min_pose_rate:
                issues.append(("WARN", f"Pose rate LOW: {rate:.1f} Hz"))
            else:
                issues.append(("OK", f"Pose rate: {rate:.1f} Hz"))
        
        # TF
        try:
            self.tf_buffer.lookup_transform(self.map_frame, self.base_frame, rospy.Time(0), rospy.Duration(0.1))
            issues.append(("OK", "TF tree valid"))
        except Exception as e:
            issues.append(("WARN", f"TF lookup failed: {type(e).__name__}"))
        
        # Time sync
        if self.time_sync_ms is not None:
            if self.time_sync_ms > self.max_time_sync_ms:
                issues.append(("WARN", f"Time sync: {self.time_sync_ms:.1f} ms"))
            else:
                issues.append(("OK", f"Time sync: {self.time_sync_ms:.1f} ms"))
        
        # CPU / RAM
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent
        if cpu > self.max_cpu: issues.append(("WARN", f"CPU: {cpu:.0f}%"))
        else: issues.append(("OK", f"CPU: {cpu:.0f}%"))
        if ram > self.max_ram: issues.append(("WARN", f"RAM: {ram:.0f}%"))
        else: issues.append(("OK", f"RAM: {ram:.0f}%"))
        
        # Disk
        disk = psutil.disk_usage('/')
        free_gb = disk.free / (1024**3)
        if free_gb < self.min_disk_gb:
            issues.append(("CRITICAL", f"Disk free: {free_gb:.1f} GB"))
            critical = True
        else:
            issues.append(("OK", f"Disk free: {free_gb:.1f} GB"))
        
        # Print
        print("-" * 60)
        for lvl, txt in issues:
            self.log(lvl, txt)
        
        self.critical_active = critical
        self.diag_pub.publish(Bool(critical))
        
        if critical:
            self.log("CRITICAL", ">>> SAFETY STOP REQUIRED <<<")

if __name__ == "__main__":
    try:
        PreflightMonitor()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
