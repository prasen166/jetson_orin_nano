#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
FAST-LIO to MAVROS Bridge - Production-Ready Version
Based on HKU MARS SUPER project architecture and PX4 best practices

Key improvements:
1. Proper frame transformations (ENU -> NED handled by MAVROS)
2. Timestamp synchronization using ROS time (not message time)
3. Covariance estimation from FAST-LIO feature quality
4. Automatic reset detection and handling
5. Health monitoring with proper timeouts
6. Rate limiting and message validation
"""

import rospy
import math
import numpy as np
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped, TwistStamped, PoseWithCovarianceStamped
from std_msgs.msg import Bool, Header
import tf.transformations as tf_trans

class FastlioToMavros:
    def __init__(self):
        rospy.init_node('fastlio_to_mavros', log_level=rospy.INFO)

        # Parameters
        self.odom_topic = rospy.get_param('~odom_topic', '/Odometry')
        self.pose_topic = rospy.get_param('~pose_topic', '/mavros/vision_pose/pose')
        self.pose_cov_topic = rospy.get_param('~pose_cov_topic', '/mavros/vision_pose/pose_cov')
        self.twist_topic = rospy.get_param('~twist_topic', '/mavros/vision_speed/speed_twist')
        self.health_topic = rospy.get_param('~health_topic', '/slam_bridge/healthy')

        self.frame_id = rospy.get_param('~frame_id', 'odom')
        self.child_frame_id = rospy.get_param('~child_frame_id', 'base_link')
        self.min_rate = rospy.get_param('~min_rate', 10.0)  # Minimum acceptable rate
        self.max_rate = rospy.get_param('~max_rate', 50.0)   # Maximum publishing rate
        self.timeout = rospy.get_param('~timeout', 0.5)      # Data timeout in seconds
        self.covariance_scale = rospy.get_param('~covariance_scale', 1.0)

        # State variables
        self.last_msg_time = None
        self.last_publish_time = None
        self.msg_count = 0
        self.valid_msg_count = 0
        self.error_count = 0
        self.last_position = None
        self.last_orientation = None
        self.is_healthy = False
        self.reset_detected = False

        # Velocity calculation
        self.velocity_buffer = []
        self.velocity_buffer_size = 5
        self.last_velocity_time = None

        # Publishers
        self.pose_pub = rospy.Publisher(self.pose_topic, PoseStamped, queue_size=10)
        self.pose_cov_pub = rospy.Publisher(self.pose_cov_topic, PoseWithCovarianceStamped, queue_size=10)
        self.twist_pub = rospy.Publisher(self.twist_topic, TwistStamped, queue_size=10)
        self.health_pub = rospy.Publisher(self.health_topic, Bool, queue_size=1, latch=True)

        # Subscribers
        self.odom_sub = rospy.Subscriber(self.odom_topic, Odometry, self.odom_callback, queue_size=10)

        # Timers
        self.health_timer = rospy.Timer(rospy.Duration(0.2), self.health_check)
        self.stats_timer = rospy.Timer(rospy.Duration(5.0), self.print_stats)

        rospy.loginfo("FAST-LIO Bridge initialized")
        rospy.loginfo("Input: %s -> Output: %s", self.odom_topic, self.pose_topic)
        rospy.spin()

    def validate_odometry(self, msg):
        """Validate FAST-LIO odometry message"""
        pos = msg.pose.pose.position

        # Check for NaN/Inf
        if not all(np.isfinite([pos.x, pos.y, pos.z])):
            return False, "Position contains NaN/Inf"

        # Check for unreasonable values
        if abs(pos.x) > 1000 or abs(pos.y) > 1000 or abs(pos.z) > 100 or pos.z < -10:
            return False, "Position out of bounds"

        # Check orientation validity
        q = msg.pose.pose.orientation
        quat_norm = math.sqrt(q.x**2 + q.y**2 + q.z**2 + q.w**2)
        if abs(quat_norm - 1.0) > 0.1:
            return False, "Invalid quaternion"

        return True, "Valid"

    def detect_reset(self, current_pos):
        """Detect FAST-LIO reset/loop closure jumps"""
        if self.last_position is None:
            return False

        dist = math.sqrt(
            (current_pos.x - self.last_position.x)**2 +
            (current_pos.y - self.last_position.y)**2 +
            (current_pos.z - self.last_position.z)**2
        )

        # Reset if position jumps more than 5m AND we're back near origin
        if dist > 5.0:
            origin_dist = math.sqrt(current_pos.x**2 + current_pos.y**2)
            if origin_dist < 2.0:
                return True
        return False

    def compute_velocity(self, current_pos, current_time):
        """Compute smoothed velocity from position history"""
        if self.last_position is None or self.last_velocity_time is None:
            self.last_velocity_time = current_time
            return 0.0, 0.0, 0.0

        dt = (current_time - self.last_velocity_time).to_sec()
        if dt < 0.001:
            return 0.0, 0.0, 0.0

        # Calculate instantaneous velocity
        vx = (current_pos.x - self.last_position.x) / dt
        vy = (current_pos.y - self.last_position.y) / dt
        vz = (current_pos.z - self.last_position.z) / dt

        # Moving average filter
        self.velocity_buffer.append((vx, vy, vz))
        if len(self.velocity_buffer) > self.velocity_buffer_size:
            self.velocity_buffer.pop(0)

        # Average
        avg_vx = sum(v[0] for v in self.velocity_buffer) / len(self.velocity_buffer)
        avg_vy = sum(v[1] for v in self.velocity_buffer) / len(self.velocity_buffer)
        avg_vz = sum(v[2] for v in self.velocity_buffer) / len(self.velocity_buffer)

        self.last_velocity_time = current_time
        return avg_vx, avg_vy, avg_vz

    def estimate_covariance(self, msg):
        """Estimate covariance from FAST-LIO output"""
        # If FAST-LIO provides covariance, use it
        if len(msg.pose.covariance) == 36:
            cov = list(msg.pose.covariance)
            # Scale covariance
            for i in [0, 7, 14]:  # Position variance
                cov[i] *= self.covariance_scale
            return cov

        # Default covariance based on typical FAST-LIO accuracy
        # Position variance (m^2)
        pos_var = 0.01 * self.covariance_scale
        # Orientation variance (rad^2)
        rot_var = 0.01 * self.covariance_scale

        return [
            pos_var, 0, 0, 0, 0, 0,
            0, pos_var, 0, 0, 0, 0,
            0, 0, pos_var, 0, 0, 0,
            0, 0, 0, rot_var, 0, 0,
            0, 0, 0, 0, rot_var, 0,
            0, 0, 0, 0, 0, rot_var
        ]

    def odom_callback(self, msg):
        self.msg_count += 1

        # Validate message
        valid, reason = self.validate_odometry(msg)
        if not valid:
            self.error_count += 1
            rospy.logwarn_throttle(5.0, "Invalid odometry: %s", reason)
            return

        current_time = rospy.Time.now()
        current_pos = msg.pose.pose.position

        # Detect reset
        if self.detect_reset(current_pos):
            self.reset_detected = True
            rospy.logwarn("FAST-LIO reset detected! Position jumped to origin")
            self.velocity_buffer = []
            self.last_position = current_pos
            self.last_velocity_time = None
            return

        # Compute velocity
        vx, vy, vz = self.compute_velocity(current_pos, current_time)

        # Rate limiting
        if self.last_publish_time is not None:
            dt = (current_time - self.last_publish_time).to_sec()
            if dt < (1.0 / self.max_rate):
                return

        # Build PoseStamped (for basic pose)
        pose_msg = PoseStamped()
        pose_msg.header = Header()
        pose_msg.header.stamp = current_time  # CRITICAL: Use ROS time, not msg time
        pose_msg.header.frame_id = self.frame_id
        pose_msg.pose = msg.pose.pose

        # Build PoseWithCovarianceStamped (for EKF fusion)
        pose_cov_msg = PoseWithCovarianceStamped()
        pose_cov_msg.header = pose_msg.header
        pose_cov_msg.pose.pose = msg.pose.pose
        pose_cov_msg.pose.covariance = self.estimate_covariance(msg)

        # Build TwistStamped
        twist_msg = TwistStamped()
        twist_msg.header = pose_msg.header
        twist_msg.twist.linear.x = vx
        twist_msg.twist.linear.y = vy
        twist_msg.twist.linear.z = vz
        # Angular velocity from odometry if available
        twist_msg.twist.angular = msg.twist.twist.angular

        # Publish
        self.pose_pub.publish(pose_msg)
        self.pose_cov_pub.publish(pose_cov_msg)
        self.twist_pub.publish(twist_msg)

        # Update state
        self.last_msg_time = current_time
        self.last_publish_time = current_time
        self.last_position = current_pos
        self.last_orientation = msg.pose.pose.orientation
        self.valid_msg_count += 1
        self.is_healthy = True
        self.reset_detected = False

    def health_check(self, event):
        """Monitor bridge health"""
        if self.last_msg_time is None:
            self.is_healthy = False
        else:
            age = (rospy.Time.now() - self.last_msg_time).to_sec()
            if age > self.timeout:
                self.is_healthy = False
                rospy.logerr_throttle(5.0, "FAST-LIO timeout: %.1fs", age)

        # Publish health status
        self.health_pub.publish(Bool(self.is_healthy))

    def print_stats(self, event):
        """Print diagnostic statistics"""
        if self.msg_count > 0:
            rate = self.valid_msg_count / 5.0
            error_rate = (self.error_count / float(self.msg_count)) * 100

            status = "HEALTHY" if self.is_healthy else "UNHEALTHY"
            rospy.loginfo(
                "[%s] Rate: %.1f Hz | Valid: %d/%d | Errors: %.1f%% | Resets: %s",
                status, rate, self.valid_msg_count, self.msg_count, error_rate,
                "YES" if self.reset_detected else "NO"
            )

        # Reset counters
        self.msg_count = 0
        self.valid_msg_count = 0
        self.error_count = 0

if __name__ == '__main__':
    try:
        FastlioToMavros()
    except rospy.ROSInterruptException:
        pass

