#!/usr/bin/env python3
"""
FAST-LIO to MAVROS Bridge (Production)
======================================
FRAME CONVENTION (ROS side):
  - Pose   : ENU world-frame  -> frame_id = "map"
  - Twist  : FLU body-frame   -> frame_id = "base_link"
MAVROS handles the internal conversion to MAVLink NED/FRD.
DO NOT manually rotate into NED here.
"""

import rospy
import tf2_ros
import numpy as np
import signal
import sys

from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped, TwistStamped, TransformStamped
from mavros_msgs.srv import StreamRate, CommandHome
from mavros_msgs.msg import State


class FastLioBridge:
    def __init__(self):
        rospy.init_node("fastlio_bridge")

        # --- Parameters ---
        self.odom_topic      = rospy.get_param("~odom_topic", "/Odometry")
        self.pose_topic      = rospy.get_param("~pose_topic", "/mavros/vision_pose/pose")
        self.twist_topic     = rospy.get_param("~twist_topic", "/mavros/vision_speed/speed_twist")
        self.map_frame       = rospy.get_param("~map_frame", "map")
        self.body_frame      = rospy.get_param("~body_frame", "base_link")
        self.max_pose_age    = rospy.get_param("~max_pose_age", 0.5)
        self.max_jump_m      = rospy.get_param("~max_position_jump", 5.0)
        self.set_origin      = rospy.get_param("~set_origin", True)
        self.origin_lat      = rospy.get_param("~origin_lat", 47.3667)
        self.origin_lon      = rospy.get_param("~origin_lon", 8.5500)
        self.origin_alt      = rospy.get_param("~origin_alt", 408.0)
        self.stream_rate_hz  = rospy.get_param("~stream_rate_hz", 30)

        # --- TF broadcaster ---
        self.static_tf = tf2_ros.StaticTransformBroadcaster()

        # --- Publishers ---
        self.pub_pose  = rospy.Publisher(self.pose_topic,  PoseStamped,  queue_size=10)
        self.pub_twist = rospy.Publisher(self.twist_topic, TwistStamped, queue_size=10)

        # --- State ---
        self.last_position = None
        self.last_stamp    = rospy.Time(0)
        self.error_count   = 0
        self.max_errors    = 10
        self.ok_to_fly     = False

        # --- Signals ---
        signal.signal(signal.SIGINT,  self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

        # --- Startup sequence ---
        rospy.loginfo("[bridge] Starting FAST-LIO bridge...")
        rospy.sleep(1.0)

        # 1. Publish static TF map -> camera_init (identity)
        self._publish_static_tf()

        # 2. Wait for MAVROS before sending anything critical
        if not self._wait_for_mavros(timeout=30.0):
            rospy.logerr("[bridge] MAVROS not connected. Shutting down.")
            rospy.signal_shutdown("mavros_unavailable")
            return

        # 3. Set stream rate once (conservative 30 Hz, not 200)
        self._set_stream_rate(self.stream_rate_hz)

        # 4. Set EKF origin if requested
        if self.set_origin:
            self._set_ekf_origin()

        # 5. Subscribe to FAST-LIO
        rospy.Subscriber(self.odom_topic, Odometry, self._odom_cb)
        rospy.loginfo("[bridge] Subscribed to %s", self.odom_topic)
        rospy.loginfo("[bridge] Node ready. Publishing ENU pose / FLU twist without manual NED rotation.")

    # --------------------------------------------------------------------- #
    #  Shutdown
    # --------------------------------------------------------------------- #
    def _shutdown(self, signum, frame):
        rospy.logwarn("[bridge] Shutdown signal received. Exiting.")
        rospy.signal_shutdown("signal_shutdown")
        sys.exit(0)

    # --------------------------------------------------------------------- #
    #  TF
    # --------------------------------------------------------------------- #
    def _publish_static_tf(self):
        t = TransformStamped()
        t.header.stamp    = rospy.Time.now()
        t.header.frame_id = self.map_frame
        t.child_frame_id  = "camera_init"
        t.transform.translation.x = 0.0
        t.transform.translation.y = 0.0
        t.transform.translation.z = 0.0
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = 0.0
        t.transform.rotation.w = 1.0
        self.static_tf.sendTransform(t)
        rospy.loginfo("[bridge] Static TF published: %s -> camera_init (identity)", self.map_frame)

    # --------------------------------------------------------------------- #
    #  MAVROS helpers
    # --------------------------------------------------------------------- #
    def _wait_for_mavros(self, timeout=30.0):
        try:
            rospy.wait_for_message("/mavros/state", State, timeout=timeout)
            rospy.loginfo("[bridge] MAVROS connected.")
            return True
        except rospy.ROSException:
            return False

    def _set_stream_rate(self, rate_hz, retries=3):
        for attempt in range(1, retries + 1):
            try:
                rospy.wait_for_service("/mavros/set_stream_rate", timeout=5.0)
                srv = rospy.ServiceProxy("/mavros/set_stream_rate", StreamRate)
                srv(0, rate_hz, 1)
                rospy.loginfo("[bridge] MAVROS stream rate set to %d Hz", rate_hz)
                return True
            except Exception as e:
                rospy.logwarn("[bridge] Stream rate attempt %d/%d failed: %s", attempt, retries, e)
                rospy.sleep(1.0)
        rospy.logerr("[bridge] Failed to set stream rate after %d attempts.", retries)
        return False

    def _set_ekf_origin(self, retries=5):
        rospy.loginfo("[bridge] Setting EKF origin -> lat=%.6f lon=%.6f alt=%.1f",
                      self.origin_lat, self.origin_lon, self.origin_alt)
        for attempt in range(1, retries + 1):
            try:
                rospy.wait_for_service("/mavros/cmd/set_home", timeout=5.0)
                srv = rospy.ServiceProxy("/mavros/cmd/set_home", CommandHome)
                resp = srv(current_gps=False, yaw=0.0,
                           latitude=self.origin_lat,
                           longitude=self.origin_lon,
                           altitude=self.origin_alt)
                if resp.success:
                    rospy.loginfo("[bridge] EKF origin / HOME set successfully.")
                    return True
                else:
                    rospy.logwarn("[bridge] set_home rejected (attempt %d/%d)", attempt, retries)
            except Exception as e:
                rospy.logwarn("[bridge] Origin attempt %d/%d failed: %s", attempt, retries, e)
            rospy.sleep(2.0)
        rospy.logerr("[bridge] CRITICAL: Could not set EKF origin. Vision fusion may fail!")
        return False

    # --------------------------------------------------------------------- #
    #  Validation helpers
    # --------------------------------------------------------------------- #
    def _has_nan_or_inf(self, msg):
        p = msg.pose.pose.position
        o = msg.pose.pose.orientation
        t = msg.twist.twist

        vals = [
            p.x, p.y, p.z,
            o.x, o.y, o.z, o.w,
            t.linear.x,  t.linear.y,  t.linear.z,
            t.angular.x, t.angular.y, t.angular.z,
        ]
        if any(np.isnan(v) or np.isinf(v) for v in vals):
            rospy.logerr_throttle(1.0, "[bridge] Rejecting odometry: NaN or Inf detected")
            return True
        return False

    def _normalize_quaternion(self, msg):
        q = np.array([
            msg.pose.pose.orientation.x,
            msg.pose.pose.orientation.y,
            msg.pose.pose.orientation.z,
            msg.pose.pose.orientation.w,
        ], dtype=float)
        norm = np.linalg.norm(q)
        if norm < 1e-6:
            rospy.logerr_throttle(1.0, "[bridge] Quaternion norm near zero!")
            return False
        if abs(norm - 1.0) > 0.01:
            rospy.logwarn_throttle(5.0, "[bridge] Quaternion denormalized (|q|=%.3f). Normalizing.", norm)
            q /= norm
            msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, \
            msg.pose.pose.orientation.z, msg.pose.pose.orientation.w = q
        return True

    def _check_jump(self, msg):
        p = msg.pose.pose.position
        if self.last_position is None:
            return True

        dx = p.x - self.last_position[0]
        dy = p.y - self.last_position[1]
        dz = p.z - self.last_position[2]
        dist = np.sqrt(dx*dx + dy*dy + dz*dz)

        dt = max((msg.header.stamp - self.last_stamp).to_sec(), 0.001)
        if dist > self.max_jump_m:
            rospy.logerr("[bridge] POSITION JUMP REJECTED: %.2f m in %.3f s (%.1f m/s)",
                         dist, dt, dist/dt)
            return False
        return True

    def _check_timestamp(self, msg):
        stamp = msg.header.stamp
        now   = rospy.Time.now()

        if stamp == rospy.Time(0):
            rospy.logwarn_throttle(2.0, "[bridge] Zero timestamp from FAST-LIO!")
            return False

        if stamp > now + rospy.Duration(0.2):
            rospy.logerr_throttle(1.0, "[bridge] Future timestamp detected! Clock desync.")
            return False

        age = (now - stamp).to_sec()
        if age > self.max_pose_age:
            rospy.logwarn_throttle(2.0, "[bridge] Stale odometry (%.2f s old)", age)

        return True

    # --------------------------------------------------------------------- #
    #  Main callback
    # --------------------------------------------------------------------- #
    def _odom_cb(self, msg):
        # 1. Timestamp hygiene
        if not self._check_timestamp(msg):
            return

        # 2. Data integrity
        if self._has_nan_or_inf(msg):
            self.error_count += 1
            return

        if not self._normalize_quaternion(msg):
            self.error_count += 1
            return

        # 3. SLAM divergence guard
        if not self._check_jump(msg):
            self.error_count += 1
            return

        # Reset error counter on good frame
        self.error_count = 0
        self.last_position = (msg.pose.pose.position.x,
                              msg.pose.pose.position.y,
                              msg.pose.pose.position.z)
        self.last_stamp = msg.header.stamp

        # 4. Publish PoseStamped  (ENU -> frame_id="map")
        pose_msg = PoseStamped()
        pose_msg.header.stamp    = msg.header.stamp   # PRESERVE source time
        pose_msg.header.frame_id = self.map_frame
        pose_msg.pose.position   = msg.pose.pose.position
        pose_msg.pose.orientation = msg.pose.pose.orientation
        self.pub_pose.publish(pose_msg)

        # 5. Publish TwistStamped (FLU body -> frame_id="base_link")
        twist_msg = TwistStamped()
        twist_msg.header.stamp    = msg.header.stamp
        twist_msg.header.frame_id = self.body_frame
        twist_msg.twist = msg.twist.twist
        self.pub_twist.publish(twist_msg)


if __name__ == "__main__":
    try:
        node = FastLioBridge()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
